<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Untitled Document</title>
<link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>

<?php 
// inkludere menuen fra php_menu.php på denne side
include ("php_menu.php");?>


<?php 
	// Bruges til at vise det som brugeren ser uden HTML tager det som et tag
	
	$str = "a<b>c";
	echo htmlentities($str);


?>

<?php include ("php_footer.php");?>
</body>
</html>