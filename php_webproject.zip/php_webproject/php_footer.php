<footer>
  <p>Posted by: Ida Marie Christensen</p>
  <p>Contact information: <a href="mailto:idski95@gmail.com">
  idski95@gmail.com</a>.</p>
</footer>