<?php 
// PHP_SELF - NOTE TIL MIG SELV ! Viser hvilken sti man er på
// basename - NOTE TIL MIG SELV ! bruges til at finde hen til aktielle php fil
$curpage = basename ($_SERVER['PHP_SELF']); 
?>
<ul>
<li><a href="index.php" <?php if ($curpage == 'index.php'){ echo 'class="active"';} ?>> Home</a></li>
<li><a href="page1.php" <?php if ($curpage == 'page1.php'){ echo 'class="active"';} ?>> Page1</a></li>
<li><a href="page2.php" <?php if ($curpage == 'page2.php'){ echo 'class="active"';} ?>> Page2</a></li>
<li><a href="page3.php" <?php if ($curpage == 'page3.php'){ echo 'class="active"';} ?>> Page3</a></li>
<li><a href="page4.php" <?php if ($curpage == 'page4.php'){ echo 'class="active"';} ?>> Page4</a></li>
<li><a href="page5.php" <?php if ($curpage == 'page5.php'){ echo 'class="active"';} ?>> Page5</a></li>
</ul>
